CREATE INDEX if not exists task_3_index_1 ON authored(author_id);

CREATE INDEX if not exists task_3_index_2 ON authored(pub_id);